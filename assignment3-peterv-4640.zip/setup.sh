
terraform init
terraform apply -auto-approve

